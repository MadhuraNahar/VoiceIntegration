package com.test.voice.utils;

/**
 * Created by Madhura Nahar. Copyrights reserved.
 */
public class ConstantErrorMessages {
    public static final String INVALID_COMMAND = "Invalid command.";
    public static final String NOT_DETECT_INPUT = "Buddy could not detect any inputs. Please try again.";

}
