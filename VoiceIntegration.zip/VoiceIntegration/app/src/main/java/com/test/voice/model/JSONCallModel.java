package com.test.voice.model;

/**
 * Created by Madhura Nahar.
 */
public class JSONCallModel {
    String Name;
    String Number;
    String commandName;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getNumber() {
        return Number;
    }

    public void setNumber(String number) {
        Number = number;
    }

    public String getCommandName() {
        return commandName;
    }

    public void setCommandName(String commandName) {
        this.commandName = commandName;
    }
}
