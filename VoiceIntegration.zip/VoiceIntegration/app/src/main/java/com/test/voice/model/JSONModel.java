package com.test.voice.model;

/**
 * Created by Indecomm Global Services. Copyrights reserved.
 */

public class JSONModel {

    private String commandName;
    private Object result;

    public String getCommandName() {
        return commandName;
    }

    public void setCommandName(String commandName) {
        this.commandName = commandName;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }
}
